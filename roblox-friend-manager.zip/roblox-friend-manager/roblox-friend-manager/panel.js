const state = {
  userId: null,
  username: null,
  tab: "friends",
  items: [],
  selected: new Set(),
  search: "",
  csrf: null,
  loading: false,
};

const els = {
  userInfo: document.getElementById("userInfo"),
  refreshBtn: document.getElementById("refreshBtn"),
  list: document.getElementById("list"),
  search: document.getElementById("searchInput"),
  selectAll: document.getElementById("selectAllBtn"),
  clear: document.getElementById("clearBtn"),
  action: document.getElementById("actionBtn"),
  accept: document.getElementById("acceptBtn"),
  status: document.getElementById("status"),
  counter: document.getElementById("counter"),
  totalCount: document.getElementById("totalCount"),
  tabs: document.querySelectorAll(".tab"),
  confirm: document.getElementById("confirm"),
  confirmTitle: document.getElementById("confirmTitle"),
  confirmText: document.getElementById("confirmText"),
  confirmOk: document.getElementById("confirmOk"),
  confirmCancel: document.getElementById("confirmCancel"),
};

const tabConfig = {
  friends: { label: "Unfriend" },
  requests: { label: "Decline", canAccept: true },
  followers: { label: "Remove" },
  following: { label: "Unfollow" },
};

function setStatus(text, type) {
  els.status.textContent = text || "";
  els.status.className = "status" + (type ? " " + type : "");
}

async function apiFetch(url, options = {}) {
  const opts = {
    credentials: "include",
    ...options,
    headers: { ...(options.headers || {}) },
  };
  if (options.method && options.method !== "GET") {
    if (state.csrf) opts.headers["x-csrf-token"] = state.csrf;
    opts.headers["Content-Type"] = opts.headers["Content-Type"] || "application/json";
  }

  let res = await fetch(url, opts);

  if (res.status === 403) {
    const token = res.headers.get("x-csrf-token");
    if (token) {
      state.csrf = token;
      opts.headers["x-csrf-token"] = token;
      res = await fetch(url, opts);
    }
  }

  let attempts = 0;
  while (res.status === 429 && attempts < 4) {
    attempts++;
    const wait = 2000 * attempts;
    setStatus(`Rate limited, wait a moment until it tries again automatically...`);
    await new Promise((r) => setTimeout(r, wait));
    res = await fetch(url, opts);
  }

  return res;
}

async function getAuthUser() {
  const res = await apiFetch("https://users.roblox.com/v1/users/authenticated");
  if (!res.ok) return null;
  return res.json();
}

async function fetchAllPaged(buildUrl) {
  const all = [];
  let cursor = "";
  while (true) {
    const url = buildUrl(cursor);
    const res = await apiFetch(url);
    if (!res.ok) throw new Error("Request failed: " + res.status);
    const json = await res.json();
    if (Array.isArray(json.data)) all.push(...json.data);
    if (!json.nextPageCursor) break;
    cursor = json.nextPageCursor;
  }
  return all;
}

async function fetchFriends(userId) {
  const res = await apiFetch(`https://friends.roblox.com/v1/users/${userId}/friends`);
  if (!res.ok) throw new Error("Failed to load friends");
  const json = await res.json();
  return json.data || [];
}

async function fetchRequests() {
  return fetchAllPaged((c) =>
    `https://friends.roblox.com/v1/my/friends/requests?limit=100&sortOrder=Asc${c ? "&cursor=" + encodeURIComponent(c) : ""}`
  );
}

async function fetchFollowers(userId) {
  return fetchAllPaged((c) =>
    `https://friends.roblox.com/v1/users/${userId}/followers?limit=100&sortOrder=Asc${c ? "&cursor=" + encodeURIComponent(c) : ""}`
  );
}

async function fetchFollowing(userId) {
  return fetchAllPaged((c) =>
    `https://friends.roblox.com/v1/users/${userId}/followings?limit=100&sortOrder=Asc${c ? "&cursor=" + encodeURIComponent(c) : ""}`
  );
}

async function fetchUserDetails(userIds) {
  const map = {};
  if (!userIds.length) return map;
  for (let i = 0; i < userIds.length; i += 100) {
    const batch = userIds.slice(i, i + 100);
    try {
      const res = await apiFetch("https://users.roblox.com/v1/users", {
        method: "POST",
        body: JSON.stringify({ userIds: batch, excludeBannedUsers: false }),
      });
      if (!res.ok) continue;
      const json = await res.json();
      for (const u of json.data || []) {
        map[u.id] = { name: u.name, displayName: u.displayName };
      }
    } catch {}
  }
  return map;
}

async function fetchAvatars(userIds) {
  const map = {};
  if (!userIds.length) return map;
  for (let i = 0; i < userIds.length; i += 100) {
    const batch = userIds.slice(i, i + 100);
    const url = `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${batch.join(",")}&size=48x48&format=Png&isCircular=true`;
    try {
      const res = await apiFetch(url);
      if (!res.ok) continue;
      const json = await res.json();
      for (const item of json.data || []) {
        if (item.imageUrl) map[item.targetId] = item.imageUrl;
      }
    } catch {}
  }
  return map;
}

async function unfriend(userId) {
  return apiFetch(`https://friends.roblox.com/v1/users/${userId}/unfriend`, { method: "POST" });
}

async function declineRequest(userId) {
  return apiFetch(`https://friends.roblox.com/v1/users/${userId}/decline-friend-request`, { method: "POST" });
}

async function acceptRequest(userId) {
  return apiFetch(`https://friends.roblox.com/v1/users/${userId}/accept-friend-request`, { method: "POST" });
}

async function unfollow(userId) {
  return apiFetch(`https://friends.roblox.com/v1/users/${userId}/unfollow`, { method: "POST" });
}

async function blockUser(userId) {
  const res = await apiFetch(`https://apis.roblox.com/user-blocking-api/v1/users/${userId}/block-user`, { method: "POST" });
  if (res.ok) return res;
  return apiFetch(`https://accountsettings.roblox.com/v1/users/${userId}/block`, { method: "POST" });
}

async function unblockUser(userId) {
  const res = await apiFetch(`https://apis.roblox.com/user-blocking-api/v1/users/${userId}/unblock-user`, { method: "POST" });
  if (res.ok) return res;
  return apiFetch(`https://accountsettings.roblox.com/v1/users/${userId}/unblock`, { method: "POST" });
}

async function blockThenUnblock(userId) {
  const blockRes = await blockUser(userId);
  if (!blockRes.ok && blockRes.status !== 404 && blockRes.status !== 409) return blockRes;
  await new Promise((r) => setTimeout(r, 400));
  const unblockRes = await unblockUser(userId);
  if (!unblockRes.ok && unblockRes.status !== 404) return unblockRes;
  return { ok: true, status: 200 };
}

async function loadTab() {
  if (!state.userId) return;
  state.loading = true;
  state.items = [];
  state.selected.clear();
  render();
  setStatus("Loading...");

  try {
    let raw;
    if (state.tab === "friends") raw = await fetchFriends(state.userId);
    else if (state.tab === "requests") raw = await fetchRequests();
    else if (state.tab === "followers") raw = await fetchFollowers(state.userId);
    else if (state.tab === "following") raw = await fetchFollowing(state.userId);

    const items = raw.map((u) => ({
      id: u.id,
      name: u.name || "",
      displayName: u.displayName || "",
      avatar: null,
    }));

    const ids = items.map((i) => i.id);

    const needsHydration = items.some((i) => !i.name || !i.displayName);
    if (needsHydration) {
      const details = await fetchUserDetails(ids);
      for (const item of items) {
        const d = details[item.id];
        if (d) {
          if (!item.name) item.name = d.name || "";
          if (!item.displayName) item.displayName = d.displayName || item.name;
        }
      }
    }

    for (const item of items) {
      if (!item.displayName) item.displayName = item.name;
    }

    const avatars = await fetchAvatars(ids);
    for (const item of items) item.avatar = avatars[item.id] || null;

    state.items = items;
    setStatus("");
  } catch (err) {
    setStatus(err.message || "Failed to load", "error");
  } finally {
    state.loading = false;
    render();
  }
}

function render() {
  els.totalCount.textContent = `${state.items.length} total`;
  els.counter.textContent = `${state.selected.size} selected`;

  const cfg = tabConfig[state.tab];
  els.action.textContent = cfg.label;
  els.action.disabled = state.selected.size === 0;

  if (cfg.canAccept) {
    els.accept.classList.remove("hidden");
    els.accept.disabled = state.selected.size === 0;
  } else {
    els.accept.classList.add("hidden");
  }

  const filtered = state.items.filter((i) => {
    if (!state.search) return true;
    const q = state.search.toLowerCase();
    return i.name.toLowerCase().includes(q) || i.displayName.toLowerCase().includes(q);
  });

  if (state.loading) {
    els.list.innerHTML = `<div class="empty">Loading...</div>`;
    return;
  }

  if (filtered.length === 0) {
    els.list.innerHTML = `<div class="empty">${state.items.length === 0 ? "Nothing here" : "No matches"}</div>`;
    return;
  }

  els.list.innerHTML = "";
  for (const item of filtered) {
    const card = document.createElement("div");
    card.className = "card" + (state.selected.has(item.id) ? " selected" : "");
    card.dataset.id = item.id;

    const avatar = document.createElement("img");
    avatar.className = "avatar";
    avatar.src = item.avatar || "";
    avatar.alt = "";
    avatar.onerror = () => { avatar.style.background = "#393b3d"; avatar.removeAttribute("src"); };

    const info = document.createElement("div");
    info.className = "card-info";
    const name = document.createElement("div");
    name.className = "card-name";
    name.textContent = item.displayName || "Unknown";
    const uname = document.createElement("div");
    uname.className = "card-username";
    uname.textContent = item.name || "";
    info.append(name, uname);

    const cb = document.createElement("div");
    cb.className = "checkbox";

    card.append(avatar, info, cb);
    card.addEventListener("click", () => toggleSelect(item.id));
    els.list.appendChild(card);
  }
}

function toggleSelect(id) {
  if (state.selected.has(id)) state.selected.delete(id);
  else state.selected.add(id);
  render();
}

function showConfirm(title, text) {
  return new Promise((resolve) => {
    els.confirmTitle.textContent = title;
    els.confirmText.textContent = text;
    els.confirm.classList.remove("hidden");
    const ok = () => { cleanup(); resolve(true); };
    const cancel = () => { cleanup(); resolve(false); };
    function cleanup() {
      els.confirm.classList.add("hidden");
      els.confirmOk.removeEventListener("click", ok);
      els.confirmCancel.removeEventListener("click", cancel);
    }
    els.confirmOk.addEventListener("click", ok);
    els.confirmCancel.addEventListener("click", cancel);
  });
}

async function runAccept() {
  if (state.selected.size === 0) return;
  const ids = Array.from(state.selected);
  const ok = await showConfirm(
    "Accept requests?",
    `This will accept ${ids.length} friend request${ids.length === 1 ? "" : "s"}.`
  );
  if (!ok) return;

  els.accept.disabled = true;
  els.action.disabled = true;
  let done = 0;
  let failed = 0;

  for (const id of ids) {
    setStatus(`Working ${done + failed + 1}/${ids.length}...`);
    let res;
    try {
      res = await acceptRequest(id);
      if (res && res.ok) {
        done++;
        state.items = state.items.filter((i) => i.id !== id);
        state.selected.delete(id);
        render();
      } else {
        failed++;
      }
    } catch {
      failed++;
    }
    if (res && res.status === 429) {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }

  setStatus(`Done. ${done} accepted${failed ? ", " + failed + " failed" : ""}.`, failed ? "error" : "success");
  render();
}

async function runAction() {
  if (state.selected.size === 0) return;
  const cfg = tabConfig[state.tab];
  const ids = Array.from(state.selected);
  const ok = await showConfirm(
    `${cfg.label}?`,
    `This will ${cfg.label.toLowerCase()} ${ids.length} user${ids.length === 1 ? "" : "s"}.`
  );
  if (!ok) return;

  els.action.disabled = true;
  if (els.accept) els.accept.disabled = true;
  let done = 0;
  let failed = 0;
  let lastError = "";

  for (const id of ids) {
    setStatus(`Working ${done + failed + 1}/${ids.length}...`);
    let res;
    try {
      if (state.tab === "friends") {
        res = await unfriend(id);
      } else if (state.tab === "requests") {
        res = await declineRequest(id);
      } else if (state.tab === "followers") {
        res = await blockThenUnblock(id);
      } else if (state.tab === "following") {
        res = await unfollow(id);
      }

      if (res && res.ok) {
        done++;
        state.items = state.items.filter((i) => i.id !== id);
        state.selected.delete(id);
        render();
      } else {
        failed++;
        if (res) lastError = `HTTP ${res.status}`;
      }
    } catch (e) {
      failed++;
      lastError = e.message || "network error";
    }
    if (res && res.status === 429) {
      await new Promise((r) => setTimeout(r, 1500));
    }
  }

  const errSuffix = failed && lastError ? ` (${lastError})` : "";
  setStatus(`Done. ${done} succeeded${failed ? ", " + failed + " failed" + errSuffix : ""}.`, failed ? "error" : "success");
  render();
}

function bindUi() {
  els.tabs.forEach((t) => {
    t.addEventListener("click", () => {
      els.tabs.forEach((x) => x.classList.remove("active"));
      t.classList.add("active");
      state.tab = t.dataset.tab;
      state.search = "";
      els.search.value = "";
      loadTab();
    });
  });

  els.refreshBtn.addEventListener("click", () => loadTab());

  els.search.addEventListener("input", (e) => {
    state.search = e.target.value.trim();
    render();
  });

  els.selectAll.addEventListener("click", () => {
    const filtered = state.items.filter((i) => {
      if (!state.search) return true;
      const q = state.search.toLowerCase();
      return i.name.toLowerCase().includes(q) || i.displayName.toLowerCase().includes(q);
    });
    for (const i of filtered) state.selected.add(i.id);
    render();
  });

  els.clear.addEventListener("click", () => {
    state.selected.clear();
    render();
  });

  els.action.addEventListener("click", runAction);
  els.accept.addEventListener("click", runAccept);

  bindMarquee();
}

function bindMarquee() {
  const list = els.list;
  let pressed = false;
  let dragged = false;
  let startX = 0;
  let startY = 0;
  let baseSelection = null;
  let additive = false;
  let box = null;
  let suppressNextClick = false;

  list.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    pressed = true;
    dragged = false;
    additive = !(e.altKey);
    baseSelection = new Set(state.selected);
    const rect = list.getBoundingClientRect();
    startX = e.clientX - rect.left + list.scrollLeft;
    startY = e.clientY - rect.top + list.scrollTop;
  });

  window.addEventListener("mousemove", (e) => {
    if (!pressed) return;
    const rect = list.getBoundingClientRect();
    const x = e.clientX - rect.left + list.scrollLeft;
    const y = e.clientY - rect.top + list.scrollTop;
    const dx = x - startX;
    const dy = y - startY;

    if (!dragged && Math.abs(dx) + Math.abs(dy) > 5) {
      dragged = true;
      box = document.createElement("div");
      box.className = "marquee";
      list.appendChild(box);
    }

    if (!dragged) return;

    const left = Math.min(startX, x);
    const top = Math.min(startY, y);
    const width = Math.abs(dx);
    const height = Math.abs(dy);
    box.style.left = left + "px";
    box.style.top = top + "px";
    box.style.width = width + "px";
    box.style.height = height + "px";

    const next = new Set(baseSelection);
    const cards = list.querySelectorAll(".card");
    const boxRight = left + width;
    const boxBottom = top + height;

    for (const card of cards) {
      const id = parseInt(card.dataset.id, 10);
      const cLeft = card.offsetLeft;
      const cTop = card.offsetTop;
      const cRight = cLeft + card.offsetWidth;
      const cBottom = cTop + card.offsetHeight;
      const intersects =
        cLeft < boxRight &&
        cRight > left &&
        cTop < boxBottom &&
        cBottom > top;
      if (intersects) {
        if (additive) next.add(id);
        else next.delete(id);
      }
    }

    state.selected = next;
    render();
  });

  window.addEventListener("mouseup", () => {
    if (!pressed) return;
    pressed = false;
    if (dragged) {
      suppressNextClick = true;
      if (box && box.parentNode) box.parentNode.removeChild(box);
      box = null;
    }
    dragged = false;
    baseSelection = null;
  });

  list.addEventListener("click", (e) => {
    if (suppressNextClick) {
      suppressNextClick = false;
      e.stopPropagation();
      e.preventDefault();
    }
  }, true);
}

async function init() {
  bindUi();
  setStatus("Checking sign in...");
  const user = await getAuthUser();
  if (!user || !user.id) {
    setStatus("You are not signed in to roblox.com in this browser. Sign in and refresh.", "error");
    els.userInfo.textContent = "Not signed in";
    return;
  }
  state.userId = user.id;
  state.username = user.name;
  els.userInfo.textContent = `${user.displayName || user.name} (${user.name})`;
  await loadTab();
}

init();
