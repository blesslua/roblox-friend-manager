chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("panel.html");
  const existing = await chrome.tabs.query({ url });
  if (existing.length > 0) {
    chrome.tabs.update(existing[0].id, { active: true });
    chrome.windows.update(existing[0].windowId, { focused: true });
  } else {
    chrome.tabs.create({ url });
  }
});
