# Roblox Friend Manager

A Chrome extension that gives you a single panel to bulk manage your Roblox friends, requests, sent requests, followers, and following.

## Features
- View friends, incoming friend requests, sent requests, followers, and following
- Multi-select with click, plus Select All on the current filter
- Search by username or display name
- Bulk actions:
  - Unfriend
  - Decline incoming requests
  - Cancel sent requests
  - Unfollow
- Confirmation prompt before any destructive action

## Install (developer mode)
1. Download or clone this folder
2. Open `chrome://extensions` in Chrome or any Chromium browser (Edge, Brave, Opera)
3. Turn on **Developer mode** (top right)
4. Click **Load unpacked** and select the `roblox-friend-manager` folder
5. Make sure you are signed in to https://www.roblox.com in the same browser
6. Click the extension icon to open the panel

## How it works
The extension calls the official `friends.roblox.com`, `users.roblox.com`, and `thumbnails.roblox.com` endpoints using your existing browser session cookies. CSRF tokens are handled automatically. There is no external server, no proxy, and no credentials stored anywhere.

## Notes
- A small delay is added between bulk actions to avoid rate limiting. Very large bulk operations may take time.
- If you get repeated failures, refresh the tab. Roblox sometimes invalidates the CSRF token on rapid requests.
- This extension is unofficial and not affiliated with Roblox. Use it at your own discretion and follow Roblox's Terms of Use.
